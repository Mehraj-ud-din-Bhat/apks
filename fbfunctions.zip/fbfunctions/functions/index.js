const functions = require('firebase-functions');
const admin = require('firebase-admin');
const { user } = require('firebase-functions/v1/auth');


admin.initializeApp();

var ORDERS_COLLECTION="orders"
var TOPIC_NEW_ORDER="NEW_ORDER_PUSH"
exports.sendNotificationOnNewOrder = functions.firestore

    .document(ORDERS_COLLECTION+'/{docId}')
    .onCreate(async (snap, context) => {
        const newValue = snap.data();
        const payload = {
            notification: {
                title: "New Order Received",
                body: "You have received a new order,please check."
            },
        };



        try {
            await admin.messaging().sendToTopic(TOPIC_NEW_ORDER, payload);
            console.log('Notification sent successfully');
        } catch (error) {
            console.error('Error sending notification:', error);
        }
    });

exports.sendNotification = functions.https.onRequest((req, res) => {
    try{

        
          const message = {
            notification: {
              title: "New Order Received",
              body: "You have received a new order,please check.",
              topic: TOPIC_NEW_ORDER
            }
          };
          const options = {
            priority: "high",
            timeToLive: 60 * 60 * 24
        };
        
          admin.messaging().sendToTopic(TOPIC_NEW_ORDER,message,options)
            .then((response) => {
              console.log('Successfully sent message:', response);
              res.status(200).send('Notification sent');
            })
            .catch((error) => {
              console.log('Error sending message:', error);
              res.status(500).send(error);
            });
        
        
          return {};
            } catch (error) {
                res.status(500).send(error)
              }
  });



//-------------------------------------
//SEND OTP
//-------------------------------------

// Request Header :

// {

// "authorization":"RVZzXcforW3d6qDgJxS7a02hA8lBOmTwNnYIiG5LejMFQ4t1bpNxKl08hB6dwtrI9OpQU13CAfVvqnFe"
// "Content-Type":"application/json"
// }

// Request Json Body :

// {

// "route" : "dlt",
// "sender_id" : "GEDAY",
// "message" : "171435",
// "variables_values" : "55|",
// "flash" : 0,
// "numbers" : "",
// }


exports.sendOTP= functions.https.onCall(async (data, context) => {
 let mobileNumber= data.mobileNumber;
  
  if (!mobileNumber) {
    throw new functions.https.HttpsError('invalid-argument', 'The function must be called with a mobile Number.');
  }
  let mobileWithoutPlus=mobileNumber
  mobileNumber="+91"+mobileNumber
  // Generate a 4-digit OTP
  const otp = Math.floor(1000 + Math.random() * 9000).toString();
  const isEligible= await isEligibleToSendOTP(mobileNumber)
  if(!isEligible)
    {
      return { isOTPSent:false ,message: 'Please try after 30 seconds' };

    }


  const otpsendResponse=await sendOTPViaAPI(mobileWithoutPlus,otp)
  if(otpsendResponse.isError==true)
    {
      throw new functions.https.HttpsError('unknown',  otpsendResponse);
    }
     // Note the current timestamp
  const timestamp = Date.now();
  const key = generateAlphanumericKey()

  // Store the OTP and timestamp in Firestore
  try {
     const db= admin.firestore()
     const user= db.collection('users').doc(mobileNumber)

     const data={}
     data['otp']={
      otp: otp,
      otpKey:key,
      createdAt: timestamp
     }
     user.set(data,{ merge: true });

    return { OTPKey:key,isOTPSent:true, message: 'OTP sent successfully' };
  } catch (error) {
    throw new functions.https.HttpsError('unknown',  error);
  }
});


async function sendOTPViaAPI(mobileNumber,OTP) {
    try {

      // Define the request headers
const headers = {
  'Authorization': 'RVZzXcforW3d6qDgJxS7a02hA8lBOmTwNnYIiG5LejMFQ4t1bpNxKl08hB6dwtrI9OpQU13CAfVvqnFe',
  'Content-Type': 'application/json'
};

// Define the request body
const body = {
  route: 'dlt',
  sender_id: 'GEDAY',
  message: '171435',
  variables_values: OTP,
  flash: 0,
  numbers: mobileNumber
};
const url="https://www.fast2sms.com/dev/bulkV2"
        // Send the POST request
        const response = await fetch(url, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(body)
        });

        // Check if the response is okay
        if (!response.ok) {
            return  {
              isError:true,
               error: `${response.status}`}
        }

        // Parse and return the JSON response
        const data = await response.json();
        data.isError=false;
        return data;
  
      } catch (error) {
        return error
    }
}
function generateAlphanumericKey(length = 16) {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let key = '';
  for (let i = 0; i < length; i++) {
      const randomIndex = Math.floor(Math.random() * characters.length);
      key += characters[randomIndex];
  }
  return key;
}

async function isEligibleToSendOTP(mobileNumber){
  try{
    const db= admin.firestore()
    const docSnap = await db.collection('users').doc(mobileNumber).get()
    let  user= await docSnap.data()
    let otpData= user.otp;
    const timestampNow = Date.now();
    const createdAt   =  otpData.createdAt
    const timeDifference = timestampNow - createdAt;
    const halfSecond=30000;
    if (timeDifference > halfSecond) {
       return true
    }
    return false

  }catch(error){
    return true
  }

}
6006172824
//End Send OTP
exports.validateOTP= functions.https.onCall(async (data, context) => {
  let user=null;
  let otpData=null
  try {
  let mobileNumber= data.mobileNumber;
  let OTP= data.OTP;
  let KEY= data.KEY;
   
   if (!mobileNumber || !OTP || !KEY) {
     throw new functions.https.HttpsError('invalid-argument', 'Required Parameters missing');
   }
    mobileNumber="+91"+mobileNumber

    const db= admin.firestore()
    const docSnap = await db.collection('users').doc(mobileNumber).get()
    user= await docSnap.data()
    if(!user)
      {
        throw new functions.https.HttpsError('unknown',  "Entity not found");
      }
      const timestampNow = Date.now();
      otpData= user.otp;
      const createdAt   =  otpData.createdAt
      const assignedKey =  otpData.otpKey
      const assignedOTP =  otpData.otp
     if(assignedKey==KEY && assignedOTP==OTP)
        {
          const fiveMinutesInMilliseconds = 5 * 60 * 1000;
          const timeDifference = timestampNow - createdAt;
          if (timeDifference > fiveMinutesInMilliseconds) {
             return { isValid:false,isExpired:true, message: 'OTP expired'};
          }
       return { OTPkey: KEY,isValid:true, message: 'OTP Validated successfully' };
        }else{
          return { isValid:false, message: 'OTP Invalid'};
        }
  
    } catch (error) {
     throw new functions.https.HttpsError('unknown', error);
   }
 });