const functions = require('firebase-functions');
const admin = require('firebase-admin');

admin.initializeApp();

exports.sendNotification = functions.https.onCall((data, context) => {
var TOPIC_NEW_ORDER="NEW_ORDER_PUSH"

  const message = {
    notification: {
      title: "Genesha Test",
      body: "Alert",
      topic: TOPIC_NEW_ORDER
    },
    android: {
      priority: 'high', // Set notification priority (optional)
    },
   // com.groceryeveryday.deliveryboy
    token: data.token, // Replace with the recipient's FCM token
  };

  admin.messaging().send(message)
    .then((response) => {
      console.log('Successfully sent message:', response);
    })
    .catch((error) => {
      console.log('Error sending message:', error);
    });

  return {};
});